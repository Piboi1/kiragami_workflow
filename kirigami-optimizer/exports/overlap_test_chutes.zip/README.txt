OVERLAP TEST CHUTES (all variants of design_0057: 28 rings, 4 cuts/ring, spacing exponent 1.189, inner radius 0.689 in, 10 in diameter)
Units: inches. Only the overlap changes between chutes; everything else is identical.

CONTROL
  design_0057.dxf              outer 7.8 deg, innermost ring 1.3 deg (the chute you already dropped; re-drop it in the same session)

INNER-OVERLAP SET (outer rings fixed at 7.8 deg; overlap ramps up over the first 5 rings)
  design_0057_in00.dxf         innermost ring 0 deg
  design_0057_in06.dxf         innermost ring 0.6 deg
  design_0057_in25.dxf         innermost ring 2.5 deg
  design_0057_in40.dxf         innermost ring 4.0 deg
  design_0057_in78.dxf         innermost ring 7.8 deg (no ramp, all rings 7.8)
  Only the central 4 rings of 28 differ between these chutes.

OUTER-OVERLAP SET (the inner ring scales with the outer, fixed ratio 1/6)
  design_0057_ov04.dxf         outer 4 deg   (innermost 0.67)
  design_0057_ov12.dxf         outer 12 deg  (innermost 2.0)
  design_0057_ov18.dxf         outer 18 deg  (innermost 3.0)
  design_0057_ov26.dxf         outer 26 deg  (innermost 4.33)

HOW TO RUN IT
  - One session, same people, same sheet material and cutting method for every chute, control included.
  - 10-15 trials per chute (5 trials = about +-10% noise in Cd, too coarse to see small differences).
  - Write down each chute's stretch height (overlap changes how deep it hangs).
  - Time after the 2 s pre-fall, as before. Use design_0057_control sheet row as the reference.
  - Use drop_test_log_template.csv to record trials; send the filled rows back for analysis.
  - If you cannot do all 10 in one session: do the inner set first (it tests the "tiny inner overlap is best" idea) and include the control in each session.
NOTE: at 0 deg the cut ends of neighbouring rings just meet; cut the innermost rings carefully so they do not tear.
