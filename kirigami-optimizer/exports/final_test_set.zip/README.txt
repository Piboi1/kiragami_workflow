FINAL TEST SET (uniform overlap 9-13 deg, plus the 45 degree chute)
Uniform chutes: same layout as design_0057 (28 rings, 4 cuts per ring, spacing exponent 1.189, inner radius 0.689 in, 10 in diameter); inner overlap = outer overlap on every ring.

 chute                         what it is                                         predicted time (indoors, 13 ft)
 design_0057_in78.dxf          CONTROL: uniform 7.8 deg (already cut/dropped)      1.19 s (measured today)
 design_0057_uni09.dxf         uniform 9 deg                                       about 1.20 s
 design_0057_uni10.dxf         uniform 10 deg                                      about 1.17 s
 design_0057_uni11.dxf         uniform 11 deg                                      about 1.13 s
 design_0057_uni12.dxf         uniform 12 deg                                      about 1.09 s
 design_0057_uni13.dxf         uniform 13 deg                                      about 1.06 s
 design_45deg_r13_c10.dxf      13 rings, 10 cuts, equal ring spacing, overlap 10-12 deg   no time prediction; predicted stretch height 10.5 cm (9.7-12.7), slope about 46 deg
Predictions are the straight lines of REVIEW.md section 30, accuracy about +-0.05 s.

PROTOCOL (one session, indoors, 13 ft timed segment)
 - Same people, same sheet material and cutting method for every chute.
 - 8 trials per chute (5 is the minimum). Interleave the chutes round-robin and change the order every round; re-drop the control (in78) at the start, middle and end.
 - Measure each chute's stretch height before dropping (for the 45 deg chute this is the key measurement: about 10-11 cm means about 45 deg).
 - Log in final_log_template.csv and send the rows back.

HOW THE RESULT WILL BE READ
 - 9 to 13 deg: with 8 trials per chute the trend over the five chutes is measured to about +-0.004 s per degree (expected -0.038), so the cutoff is clearly visible; neighbouring chutes (1 deg apart, about 0.038 s) are not separable one by one (their difference has an uncertainty of 0.014 s).
 - 45 deg chute: support for the theory = a time clearly above the 7.8-9 deg plateau chutes (more than about 0.05 s). Worse = the shallow dome loses.
