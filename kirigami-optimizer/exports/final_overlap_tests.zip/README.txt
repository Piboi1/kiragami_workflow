FINAL OVERLAP TESTS (team rule: innermost-ring overlap >= 1 deg; nothing lower)
All chutes are design_0057 (28 rings, 4 cuts/ring, spacing exponent 1.189, inner radius 0.689 in, 10 in diameter) with ONLY the overlap changed.

 #  chute                    overlap range (inner ring - outer rings)   set
 1  design_0057 (control)    1.3 - 7.8 deg                              existing chute, re-drop it
 2  design_0057_in10         1.0 - 7.8 deg                              inner set (the 1 deg floor)
 3  design_0057_in25         2.5 - 7.8 deg                              inner set
 4  design_0057_in40         4.0 - 7.8 deg                              inner set
 5  design_0057_in78         7.8 - 7.8 deg (no ramp)                    inner set
 6  design_0057_ov12         2.0 - 12.0 deg                             outer set
 7  design_0057_ov18         3.0 - 18.0 deg                             outer set
 8  design_0057_ov26         4.33 - 26.0 deg                            outer set
(Dropped from the earlier files because the innermost ring is under 1 deg: in00, in06, ov04.)

PROTOCOL
 - One session, same people, same sheet material and cutting method for all 8 chutes.
 - Stage 1: 15 trials per chute (120 drops). Interleave the chutes (round-robin, change the order each round) so wind, fatigue and
   timing drift hit every chute equally. Drop the control again at the start, middle and end.
 - Stage 2: the best two or three chutes from stage 1, 20 more trials each, interleaved (head to head).
 - Record each chute's stretch height. Time after the 2 s pre-fall, as before.
 - Log in final_test_log_template.csv (20 trial columns), send the rows back for analysis.
