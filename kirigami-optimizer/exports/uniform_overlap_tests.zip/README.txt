UNIFORM-OVERLAP TEST CHUTES (inner overlap = outer overlap on every ring, no ramp)
Base layout = design_0057: 28 rings, 4 cuts per ring, ring spacing exponent 1.189, inner radius 0.689 in, 10 in diameter. Only the overlap differs.

ASKED FOR (the cutoff test)
  design_0057_uni10.dxf    uniform 10 deg   predicted time about 1.17 s (indoors, 13 ft)
  design_0057_uni12.dxf    uniform 12 deg   predicted time about 1.09 s
  design_0057_uni14.dxf    uniform 14 deg   predicted time about 1.02 s
OPTIONAL EXTRAS
  design_0057_uni09.dxf    uniform 9 deg    predicted about 1.20 s (the estimated peak is at 9.2 deg)
  design_0057_uni11.dxf    uniform 11 deg   predicted about 1.13 s
  design_0057_square.dxf   theory chute: overlap falls from 6.7 deg (ring 1) to 2.2 deg (outermost ring) so that the overlap region
                           (arc length x ring pitch) is about square on every ring (arc/pitch 0.85-1.21). No prediction: outer overlap
                           below 7.8 deg has not been tested; ring 1 arc/pitch is 1.0, well above the opening threshold (0.15 failed, 0.3 opened).
Predictions come from the straight lines in REVIEW.md section 30 (rising line to 9.2 deg, falling line 1.5513 - 0.03807 x), accuracy about +-0.05 s.

HOW TO RUN IT
  - Indoors at 13 ft in the same session as in78 (uniform 7.8 deg, 1.194 s) and ov12 (ramp 2-12 deg, 1.122 s); drop in78 again as the control.
  - 5-10 trials each, interleaved, same people and sheet material. Write down each chute's stretch height.
  - What to look for: the time starts to fall below the 7.8 deg plateau at about 9-10 deg (the cutoff); uni14 should be clearly lower.
